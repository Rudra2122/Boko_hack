
function initializeApp() {
    console.log('Notes app initialization started');
    
    attachEventHandlers();
}

function attachEventHandlers() {
    console.log('Attaching event handlers');
    
    const form = document.getElementById('note-form');
    if (form) {
        console.log('Found note form, attaching submit handler');
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            console.log('Form submitted');
            saveNote();
        });
    } else {
        console.error('Note form not found');
    }

    const searchButton = document.getElementById('search-button');
    if (searchButton) {
        console.log('Found search button, attaching click handler');
        searchButton.addEventListener('click', function() {
            console.log('Search button clicked');
            searchNotes();
        });
    } else {
        console.error('Search button not found');
    }

    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function() {
            const noteId = this.getAttribute('data-note-id');
            deleteNote(noteId);
        });
    });
}

function getCSRFToken() {
    return document.querySelector('input[name="csrf_token"]').value;  // ✅ Fetch CSRF token
}

function saveNote() {
    const title = document.getElementById('note-title').value;
    const content = document.getElementById('note-content').value;
    const csrfToken = getCSRFToken();  // ✅ Get CSRF token

    if (!csrfToken) {
        console.error("CSRF token is missing!");
        return;
    }

    const formData = new FormData();
    formData.append('title', title);
    formData.append('content', content);
    formData.append('csrf_token', csrfToken);  // ✅ Include CSRF token

    fetch('/apps/notes/create', {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRFToken': csrfToken  // ✅ Send CSRF token in headers
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Note saved successfully!');
            location.reload();
        } else {
            alert('Error saving note: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function searchNotes() {
    const query = document.getElementById('search').value;
    console.log('Searching for:', query);
    
    fetch(`/apps/notes/search?q=${encodeURIComponent(query)}`)
    .then(response => {
        console.log('Search response status:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('Search results:', data);
        
        const notesList = document.getElementById('notes-list');
        if (!notesList) {
            console.error('Notes list element not found');
            return;
        }
        
        if (data.success && Array.isArray(data.notes)) {
            console.log(`Found ${data.notes.length} notes matching query`);
            
            if (data.notes.length === 0) {
                notesList.innerHTML = '<div class="note-card"><p>No notes found matching your search.</p></div>';
                return;
            }
            
            notesList.innerHTML = '';
            data.notes.forEach(note => {
                const noteElement = document.createElement('div');
                noteElement.className = 'note-card';
                noteElement.innerHTML = `
                    <h3>${note.title}</h3>
                    <div class="note-content">${note.content}</div>
                    <div class="note-meta">
                        ID: ${note.id} | Created: ${note.created_at}
                        <button type="button" class="delete-btn" data-note-id="${note.id}">Delete</button>
                    </div>
                `;
                notesList.appendChild(noteElement);
            });
            
            document.querySelectorAll('.delete-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const noteId = this.getAttribute('data-note-id');
                    deleteNote(noteId);
                });
            });
        } else {
            console.error('Search failed or returned invalid data');
            notesList.innerHTML = '<div class="note-card"><p>An error occurred while searching notes.</p></div>';
        }
    })
    .catch(error => {
        console.error('Search fetch error:', error);
        const notesList = document.getElementById('notes-list');
        if (notesList) {
            notesList.innerHTML = '<div class="note-card"><p>An error occurred while searching notes.</p></div>';
        }
    });
}

function deleteNote(noteId) {
    if (!confirm('Are you sure you want to delete this note?')) {
        return;
    }

    const csrfToken = document.querySelector('input[name="csrf_token"]').value;  //  Get CSRF token

    fetch(`/apps/notes/delete/${noteId}`, {
        method: 'DELETE',
        headers: {
            'X-CSRFToken': csrfToken,  // Ensure CSRF token is sent
            'Content-Type': 'application/json'  //  Specify JSON request
        }
    })
    .then(response => {
        if (!response.ok) {
            return response.text().then(text => { throw new Error(text); });  // Catch non-JSON errors
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            alert('Note deleted successfully!');
            location.reload();
        } else {
            alert('Error deleting note: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Delete error:', error);
        alert('Error deleting note. Please try again.');
    });
}


function cleanupApp() {
    console.log('Cleaning up notes app');
}

window.initializeApp = initializeApp;
window.cleanupApp = cleanupApp;

console.log('Notes script loaded and functions defined');