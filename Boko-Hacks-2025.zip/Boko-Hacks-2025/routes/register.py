from werkzeug.security import generate_password_hash
from flask import Blueprint, render_template, request, flash, redirect, url_for, session
from flask_wtf.csrf import generate_csrf
from models.user import User
from extensions import db

register_bp = Blueprint("register", __name__)

@register_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        captcha_response = request.form.get("captcha")
        stored_captcha = session.get("captcha_text")
        csrf_token = request.form.get("csrf_token")

        if not csrf_token:
            flash("CSRF token is missing.", "error")
            return redirect(url_for("register.register"))

        if not stored_captcha or captcha_response.upper() != stored_captcha:
            flash("Invalid CAPTCHA. Please try again.", "error")
            return redirect(url_for("register.register"))

        session.pop("captcha_text", None)

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash("Username already exists. Please choose a different one.", "error")
            return redirect(url_for("register.register"))

        hashed_password = generate_password_hash(password, method="pbkdf2:sha256", salt_length=16)  # Using Werkzeug
        new_user = User(username=username, password_hash=hashed_password)  # Storing hashed password
        db.session.add(new_user)
        db.session.commit()

        flash("Registration successful! You can now log in.", "success")
        return redirect(url_for("login.login"))

    return render_template("register.html", csrf_token=generate_csrf())
