from flask_wtf.csrf import generate_csrf
from flask import Blueprint, render_template, request, flash, redirect, session, url_for
from models.user import User
from extensions import db
import secrets

login_bp = Blueprint("login", __name__)

@login_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        csrf_token = request.form.get("csrf_token")
        #print(f"Received CSRF Token: {request.form.get('csrf_token')}")

        if not csrf_token:
            flash("CSRF token missing", "error")
            return redirect(url_for("login.login"))
        
        username = request.form.get("username")
        password = request.form.get("password")

        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session.clear()
            session["user"] = user.username
            session["session_id"] = secrets.token_hex(32)
            flash("Login successful!", "success")
            return redirect(url_for("hub.hub"))
        else:
            flash("Invalid username or password.", "error")

    return render_template("login.html", csrf_token=generate_csrf())  #  Pass CSRF token manually

@login_bp.route("/logout")
def logout():
    """Logs out the user and clears the session."""
    session.pop("user", None)
    session.pop("_flashes", None)
    flash("You have been logged out.", "info")
    return redirect(url_for("login.login")) 