from app import app, db  # Replace with your actual Flask app module
from models.user import User
from werkzeug.security import generate_password_hash

with app.app_context():  # Ensures Flask's database connection works
    users = User.query.all()
    for user in users:
        if not user.password_hash.startswith("pbkdf2:sha256"):  # Check if already hashed
            print(f"Fixing password for user: {user.username}")
            user.password_hash = generate_password_hash(user.password_hash, method="pbkdf2:sha256", salt_length=16)
            db.session.commit()

    print("✅ All passwords have been updated successfully!")
